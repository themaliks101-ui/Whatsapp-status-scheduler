package com.nabeel.statusscheduler

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object Scheduler {
    private const val ACTION = "com.nabeel.statusscheduler.POST_STATUS"

    fun schedule(ctx: Context, item: StatusItem) {
        val alarm = ctx.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            ctx,
            item.id.toInt(),
            Intent(ctx, ScheduleReceiver::class.java).apply {
                action = ACTION
                putExtra("id", item.id)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        if (Build.VERSION.SDK_INT >= 23) {
            alarm.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                item.whenMillis,
                pi
            )
        } else {
            alarm.setExact(AlarmManager.RTC_WAKEUP, item.whenMillis, pi)
        }
    }

    fun action() = ACTION
}
