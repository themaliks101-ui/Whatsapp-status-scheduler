package com.nabeel.statusscheduler

data class StatusItem(
    val id: Long,
    val uri: String,
    val whenMillis: Long,
    val repeatDaily: Boolean = false,
    val posted: Boolean = false
)
