package com.nabeel.statusscheduler

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Scheduler.action()) return
        val id = intent.getLongExtra("id", -1L)
        if (id < 0) return

        createChannel(context)

        val serviceIntent = Intent(context, WhatsAppAccessibilityService::class.java)
            .setAction("RUN_SCHEDULE")
            .putExtra("id", id)

        try {
            context.startService(serviceIntent)
        } catch (_: Exception) {
            notify(context, "Status scheduled", "Open Accessibility settings and enable Status Scheduler.")
        }
    }

    private fun createChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("status", "Status Scheduler", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    private fun notify(ctx: Context, title: String, text: String) {
        NotificationManagerCompat.from(ctx).notify(
            1001,
            NotificationCompat.Builder(ctx, "status")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .build()
        )
    }
}
