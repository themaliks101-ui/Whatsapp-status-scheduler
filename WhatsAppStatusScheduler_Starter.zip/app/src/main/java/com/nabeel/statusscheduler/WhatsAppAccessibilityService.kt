package com.nabeel.statusscheduler

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class WhatsAppAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        createChannel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Reserved for the state machine used in the next automation iteration.
    }

    override fun onInterrupt() {}

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "RUN_SCHEDULE") {
            val id = intent.getLongExtra("id", -1L)
            if (id >= 0) runScheduled(id)
        }
        return START_NOT_STICKY
    }

    private fun runScheduled(id: Long) {
        val item = StatusStore.all(this).firstOrNull { it.id == id } ?: return
        val mediaUri = Uri.parse(item.uri)

        // Launch WhatsApp Business. The actual Status UI automation is deliberately
        // implemented as a state machine because labels/layouts vary by WhatsApp version.
        val launch = packageManager.getLaunchIntentForPackage("com.whatsapp.w4b")
        if (launch == null) {
            notify("WhatsApp Business not found", "Install WhatsApp Business and try again.")
            return
        }

        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)

        // First milestone: open WhatsApp Business. The next state-machine step
        // locates "Updates/Status" and starts the media selection flow.
        handler.postDelayed({
            notify("Status ready", "Scheduled media is ready. UI automation can continue from WhatsApp Business.")
        }, 2500)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel("status", "Status Scheduler", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    private fun notify(title: String, text: String) {
        NotificationManagerCompat.from(this).notify(
            2001,
            NotificationCompat.Builder(this, "status")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .build()
        )
    }
}
