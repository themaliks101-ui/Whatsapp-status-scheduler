package com.nabeel.statusscheduler

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object StatusStore {
    private const val PREF = "status_store"
    private const val KEY = "items"

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun all(ctx: Context): MutableList<StatusItem> {
        val raw = prefs(ctx).getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val out = mutableListOf<StatusItem>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out += StatusItem(
                o.getLong("id"),
                o.getString("uri"),
                o.getLong("when"),
                o.optBoolean("daily", false),
                o.optBoolean("posted", false)
            )
        }
        return out.sortedBy { it.whenMillis }.toMutableList()
    }

    fun add(ctx: Context, item: StatusItem) {
        val list = all(ctx)
        list += item
        save(ctx, list)
    }

    fun update(ctx: Context, item: StatusItem) {
        val list = all(ctx)
        val idx = list.indexOfFirst { it.id == item.id }
        if (idx >= 0) list[idx] = item
        save(ctx, list)
    }

    private fun save(ctx: Context, list: List<StatusItem>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id)
                put("uri", it.uri)
                put("when", it.whenMillis)
                put("daily", it.repeatDaily)
                put("posted", it.posted)
            })
        }
        prefs(ctx).edit().putString(KEY, arr.toString()).apply()
    }
}
