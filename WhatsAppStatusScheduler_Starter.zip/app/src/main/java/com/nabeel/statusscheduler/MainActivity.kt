package com.nabeel.statusscheduler

import android.Manifest
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.text.DateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private var selectedUri: Uri? = null
    private var selectedTime: Long = System.currentTimeMillis() + 60_000L
    private lateinit var list: LinearLayout

    private val picker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            contentResolver.takePersistableUriPermission(
                it,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            selectedUri = it
            Toast.makeText(this, "Media selected", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 24)
        }

        val title = TextView(this).apply {
            text = "WhatsApp Status Scheduler"
            textSize = 26f
        }
        root.addView(title)

        val instructions = TextView(this).apply {
            text = "\n1. Select a photo/video.\n2. Choose date and time.\n3. Schedule it.\n4. Enable the Accessibility Service when prompted.\n"
            textSize = 16f
        }
        root.addView(instructions)

        val select = Button(this).apply {
            text = "Select Photo / Video"
            setOnClickListener {
                picker.launch(arrayOf("image/*", "video/*"))
            }
        }
        root.addView(select)

        val choose = Button(this).apply {
            text = "Choose Date & Time"
            setOnClickListener { chooseDateTime() }
        }
        root.addView(choose)

        val schedule = Button(this).apply {
            text = "Schedule Status"
            setOnClickListener { scheduleStatus() }
        }
        root.addView(schedule)

        val accessibility = Button(this).apply {
            text = "Enable Accessibility Automation"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        root.addView(accessibility)

        val exactAlarm = Button(this).apply {
            text = "Allow Exact Alarms"
            setOnClickListener {
                if (android.os.Build.VERSION.SDK_INT >= 31) {
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
                }
            }
        }
        root.addView(exactAlarm)

        val heading = TextView(this).apply {
            text = "\nUpcoming schedules"
            textSize = 20f
        }
        root.addView(heading)

        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        root.addView(list)

        setContentView(ScrollView(this).apply { addView(root) })

        if (android.os.Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 50)
        }
        refresh()
    }

    private fun chooseDateTime() {
        val c = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            TimePickerDialog(this, { _, hour, minute ->
                val cal = Calendar.getInstance().apply {
                    set(Calendar.YEAR, y)
                    set(Calendar.MONTH, m)
                    set(Calendar.DAY_OF_MONTH, d)
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                selectedTime = cal.timeInMillis
                Toast.makeText(this, DateFormat.getDateTimeInstance().format(cal.time), Toast.LENGTH_LONG).show()
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show()
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun scheduleStatus() {
        val uri = selectedUri ?: run {
            Toast.makeText(this, "Select media first", Toast.LENGTH_SHORT).show()
            return
        }

        if (selectedTime <= System.currentTimeMillis()) {
            Toast.makeText(this, "Choose a future time", Toast.LENGTH_SHORT).show()
            return
        }

        val item = StatusItem(
            id = System.currentTimeMillis(),
            uri = uri.toString(),
            whenMillis = selectedTime
        )

        StatusStore.add(this, item)

        val alarm = getSystemService(AlarmManager::class.java)
        if (android.os.Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) {
            Toast.makeText(this, "Allow exact alarms first", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
            return
        }

        Scheduler.schedule(this, item)
        Toast.makeText(this, "Status scheduled", Toast.LENGTH_LONG).show()
        refresh()
    }

    private fun refresh() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        StatusStore.all(this).forEach { item ->
            val row = TextView(this).apply {
                text = "\n${DateFormat.getDateTimeInstance().format(Date(item.whenMillis))}\n${item.uri}\n"
                textSize = 14f
            }
            list.addView(row)
        }
    }
}
