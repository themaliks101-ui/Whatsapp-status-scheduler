# WhatsApp Status Scheduler — Android starter

This is a native Kotlin starter for an Android WhatsApp Business Status scheduler.

## What is included

- Photo/video picker
- Date/time scheduler
- Persistent local schedule storage
- Exact AlarmManager scheduling
- Notification permission handling
- Accessibility Service declaration
- WhatsApp Business launch at the scheduled time
- Basic status queue UI

## Important

WhatsApp Business does not expose a public API for third-party apps to publish Status updates directly. The final publishing step therefore requires Android UI automation through AccessibilityService. WhatsApp UI labels and layouts can change, so that portion must be maintained as a state machine.

This starter intentionally stops after opening WhatsApp Business. The next implementation milestone is:

1. Detect the WhatsApp Business window.
2. Find the Updates/Status control by text/content-description.
3. Open Status camera/gallery.
4. Select the scheduled media.
5. Tap the send/post control.
6. Verify the status was posted.
7. Mark the schedule as posted.
8. Retry safely if a UI element is missing.

## Build

Open this folder in Android Studio and let Gradle sync.

Minimum Android: 8.0 (API 26)
Target SDK: 35

## Permissions

The app needs:
- Notifications
- Exact alarms
- Accessibility Service

The Accessibility Service must be enabled manually in Android Settings.

## WhatsApp Business package

The starter targets:

com.whatsapp.w4b

If your installed WhatsApp Business build uses a different package, update the package name in `WhatsAppAccessibilityService.kt`.
